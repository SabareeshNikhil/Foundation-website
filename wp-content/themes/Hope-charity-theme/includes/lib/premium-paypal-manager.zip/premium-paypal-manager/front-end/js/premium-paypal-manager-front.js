// JavaScript Document
(function($){
		
	$(document).ready(function(e) {
				
	});
	
})(jQuery);